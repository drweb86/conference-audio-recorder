[Translations](notices/README.md)

# Third-party notices

Conference Audio Recorder uses the components listed below. They are not covered by the CC0 dedication of the app's own code. Each keeps the license stated for it.

Package names and the license notices below are given in English, because those texts are the legal notices.

The Windows builds include the .NET runtime. It is listed with the MIT components.

## MIT

- **Avalonia** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.Desktop** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.Fonts.Inter** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.FreeDesktop** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.FreeDesktop.AtSpi** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.HarfBuzz** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.Native** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.Remote.Protocol** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.Skia** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.Themes.Fluent** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.Win32** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **Avalonia.X11** 12.1.6. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link](https://avaloniaui.net/?utm_source=nuget&utm_medium=referral&utm_content=project_homepage_link)
- **HarfBuzzSharp** 8.3.1.3. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **HarfBuzzSharp.NativeAssets.Linux** 8.3.1.3. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **HarfBuzzSharp.NativeAssets.macOS** 8.3.1.3. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **HarfBuzzSharp.NativeAssets.WebAssembly** 8.3.1.3. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **HarfBuzzSharp.NativeAssets.Win32** 8.3.1.3. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **MicroCom.Runtime** 0.11.6. Copyright 2021 © Nikita Tsukanov
- **Microsoft.IO.RecyclableMemoryStream** 3.0.1. © Microsoft Corporation. All rights reserved. [https://github.com/Microsoft/Microsoft.IO.RecyclableMemoryStream](https://github.com/Microsoft/Microsoft.IO.RecyclableMemoryStream)
- **NAudio.Alsa** 3.3.0. © Mark Heath 2026 [https://naudio.github.io/NAudio/](https://naudio.github.io/NAudio/)
- **NAudio.Core** 3.3.0. © Mark Heath 2026 [https://naudio.github.io/NAudio/](https://naudio.github.io/NAudio/)
- **NAudio.SoundFile** 3.3.0. © Mark Heath 2026 [https://naudio.github.io/NAudio/](https://naudio.github.io/NAudio/)
- **NAudio.Wasapi** 3.3.0. © Mark Heath 2026 [https://naudio.github.io/NAudio/](https://naudio.github.io/NAudio/)
- **SkiaSharp** 3.119.4. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **SkiaSharp.NativeAssets.Linux** 3.119.4. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **SkiaSharp.NativeAssets.macOS** 3.119.4. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **SkiaSharp.NativeAssets.WebAssembly** 3.119.4. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **SkiaSharp.NativeAssets.Win32** 3.119.4. © Microsoft Corporation. All rights reserved. [https://go.microsoft.com/fwlink/?linkid=868515](https://go.microsoft.com/fwlink/?linkid=868515)
- **System.Numerics.Tensors** 9.0.0. © Microsoft Corporation. All rights reserved. [https://dot.net/](https://dot.net/)
- **Tmds.DBus.Protocol** 0.94.1. Tom Deseyn

## BSD-3-Clause

- **Avalonia.Angle.Windows.Natives** 2.1.27548.20260419. Copyright 2013-2026 © The AvaloniaUI Project [https://avaloniaui.net/](https://avaloniaui.net/)
- **NLog** 6.2.2. Copyright (c) 2004-2026 NLog Project - https://nlog-project.org/ [https://nlog-project.org/](https://nlog-project.org/)

The copyright lines in each group above apply to that license text.

License names above come from each package. Read the package for the full license text.

